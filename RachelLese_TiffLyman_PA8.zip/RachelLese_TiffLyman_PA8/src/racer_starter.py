#!/usr/bin/env python
import rospy, cv2, cv_bridge, numpy, math
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan, Image

leftDist = None
rightDist = None

# scan callback
def scan_callback(msg):
    global ranges
    global leftDist
    global rightDist
    ranges = msg.ranges
    rightDist = min(ranges[250:290])
    leftDist = min(ranges[70:110])
    #left side


# img callback
bridge = cv_bridge.CvBridge()
previous_error = 0
integral = 0
output = 0
cx = 0
def img_callback(msg):
    if not msg == None:
        global img
        img = bridge.imgmsg_to_cv2(msg)
        image_in_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        lower = numpy.array([ 0, 0, 250])
        upper = numpy.array([ 0, 0, 260])
        mask = cv2.inRange(image_in_hsv,  lower, upper)
    
        h, w, d = image_in_hsv.shape
        search_top = 3 * h /4
        search_bot = search_top + 200
        mask[0:search_top-200, 0:w] = 0
        mask[search_bot:h, 0:w] = 0
        mask[0:h, 0:search_top-200] = 0
        mask[0:h, search_bot:w] = 0
        global cx
        #find the outline and the center of the "circle" that is created around the center of the "blob" that is the line
        moments = cv2.moments(mask)
        if moments['m00'] > 0:
                cx = int(moments['m10']/moments['m00']) + 100
                cy = int(moments['m01']/moments['m00'])
                cv2.circle(mask, (cx, cy), 20, (0, 0 , 0), -1)
        t = Twist()
        #PID steering from previous PA: the error is how far we are from the middle, then we determine the output through
        #calculations: error/100 was derived from follower_p, but output/25 was taken from tuning and testing to get the perfect following
        global previous_error
        global integral
        global output
        if not cx == 0:
            error = cx - w/2
            integral = integral + (error * 2)
            derivative = (error - previous_error) / 2
            output = (.121 * (error/100)) + (.121 * (error/100)) + (.121 * (error/100))
        #output the masked image to make sure we are seeing the correct outputs
        masked = cv2.bitwise_and(image_in_hsv, image_in_hsv, mask=mask)
        unmasked = cv2.cvtColor(masked, cv2.COLOR_HSV2RGB)
        real_img = bridge.cv2_to_imgmsg(unmasked)
        img_publisher.publish(real_img)
    
#not really used
# update state 
def update_state():
    global current_state
    # once we have received an image and scan start change state to forward
    if img is not None and ranges is not None:
        current_state = "FORWARD"
    #^we should delete this once we're ready to implement the stuff below
    

# pub/subs
scan_sub = rospy.Subscriber('/scan', LaserScan, scan_callback)
img_sub = rospy.Subscriber('/camera/rgb/image_raw', Image, img_callback)
cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

# init node 
rospy.init_node('racer')
rate = rospy.Rate(10)

# some variables
img_publisher = rospy.Publisher('/my_image', Image, queue_size=1)
angular_vel = math.pi /2    # radians/second
linear_vel  = 0.3           # meters/second
states = {"STOP"    : (0, 0), 
          "FORWARD" : (1, 0),
          "LEFT"    : (1, 1),
          "RIGHT"   : (1, -1)}
current_state = "STOP"
ranges = None; img = None
#global bridge

global previous_error1
global integral1
previous_error1 = 0
integral1 = 0
global previous_error2
global integral2
previous_error2 = 0
integral2 = 0
# control loop
while not rospy.is_shutdown():

    # print current state
    print(current_state)

    # change cmd_vel based on motion associated with the current state
    t = Twist()
    #update_state()
    
    #checking to see if slowing down when following the line helps
    motion = states.get(current_state, (0, 0))
    t.linear.x = linear_vel * motion[0]
    

    minDist = 1.35
    maxDist = 1.75
    if not rightDist == None and not leftDist == None:
        if rightDist < minDist:   #WHY DO WE HAVE > 3?
            current_state = "LEFT"
            print 'right < min'
            print rightDist
            error1 = minDist - rightDist
            integral1 = integral1 + (error1 * 2)
            derivative1 = (error1 - previous_error1) / 2
            output1 = (.3 * error1) + (.3 * error1) + (.3 * error1)
            t.angular.z = output1*2.5
        elif leftDist < minDist:   #WHY DO WE HAVE > 3?
            print 'left < min'
            print leftDist
            current_state = "RIGHT"
            error2 = minDist - leftDist
            integral2 = integral2 + (error2 * 2)
            derivative2 = (error2 - previous_error2) / 2
            output2 = (.3 * error2) + (.3 * error2) + (.3 * error2)
            t.angular.z = -output2*2.5
        else:
            print 'forward'
            current_state = "FORWARD"
            if output == 0:
                t.angular.z = 0
            else:
                t.angular.z = -output

    # publish velocity command
    cmd_vel_pub.publish(t)

    # runs at 10hz
    rate.sleep()