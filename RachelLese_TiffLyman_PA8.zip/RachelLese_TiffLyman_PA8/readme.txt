This PA is specifically a line follower, with a wall follower used as a fail safe. The robot takes in an image that is then filtered into a 
200x200 window that only reads the color white. From there, the moments are taken, which detects the "blob" that is the line. It then uses
a PID steering algorithm to follow said line. However, there are cases where it can lose the line; either the line is too far ahead, or it 
gets off track for some reason. In these cases, we use a wall follower. If the robot gets within 1.35m of the wall, it uses a different PID
steerer to get itself back on track so it can find the line again and correct to follow it. This happens only in select cases, mostly going
around turns. The only case that it doesnt work on is going across the "finish line". This is because the white squares cause too many blobs
and it is too hard for the robot to read. It works around the entire track, though, so we count that as a success.